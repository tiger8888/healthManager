//
//  ChatViewController.h
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"

@interface ChatViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>{
    UITableView *_tableView;
    NSMutableArray *_allChatList;

    UserModel *_toUser;
}
@property (nonatomic, retain) UserModel *toUser;

@end
