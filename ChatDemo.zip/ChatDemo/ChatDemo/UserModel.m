//
//  UserModel.m
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel
@synthesize jid = _jid, password  = _pasword, status= _status;

- (BOOL) isOnline {
    if ([self.status isEqualToString:@"unavailable"]) {
        return NO;
    }
    return YES;
}

@end
