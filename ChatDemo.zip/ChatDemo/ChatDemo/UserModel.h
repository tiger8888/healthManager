//
//  UserModel.h
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserModel : NSObject {
    NSString *_jid;
    NSString *_pasword;
    NSString *_status;
}
@property (nonatomic, copy) NSString *jid;
@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *status;

- (BOOL) isOnline;

@end
