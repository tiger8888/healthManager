//
//  QFXmppManager.h
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPFramework.h"
#import "UserModel.h"
#import "MessageModel.h"

typedef enum {
    kMsgText = 1,
    kMsgImage = 2,
    kMsgVoice = 3,
    kMsgImageUrl = 4,
    kMsgVoiceUrl = 5,

}MessageType;

@interface QFXmppManager : NSObject {
    // nsurlconnection
    XMPPStream *_xmppStream;
    void (^saveRegCb)(BOOL ret, NSError *err);      //注册block回调
    void (^saveLoginCb)(BOOL ret, NSError *err);    //登录block回调
    void (^saveFriendsCb) (NSArray *) ;             //取得好友信息回调
    void (^saveMessageCb) (MessageModel *mm);       //
    void (^saveSendMessageFinishCb)(BOOL ret);      //
    
    UserModel *_currUser;
    BOOL isInRegisting;
    NSMutableArray *_allFriendList;
}
+ (id) shareInstance;
// Jabber ID
- (void) registerUser:(NSString *)jid
    withPassword:(NSString *)pass
    withCompletion:( void (^) (BOOL ret, NSError *err))cb;

- (void) loginUser:(NSString *)jid
         withPassword:(NSString *)pass
       withCompletion:( void (^) (BOOL ret, NSError *err))cb;

- (void) goOnline;
- (void) getAllFriends:( void (^) (NSArray *) ) cb;

// callback
- (void) registerForMessage:( void (^) (MessageModel *mm) )cb;

- (void) sendMessage:(NSString *)msg withType:(MessageType)type toUser:(UserModel *)toUser withCompletion:(void (^)(BOOL ret))cb;
@end












