//
//  MessageModel.m
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import "MessageModel.h"
#import "NSData+Base64.h"
@implementation MessageModel
- (UIImage *) image {
    // msg 转化成nsdata-->uiimage
    
    if (self.msg.length < 1000) return nil;
    
    NSData *d = [NSData dataFromBase64String:self.msg];
    if (d == nil) return nil;
    UIImage *img = [[UIImage alloc] initWithData:d];
    return img;
}

@end
