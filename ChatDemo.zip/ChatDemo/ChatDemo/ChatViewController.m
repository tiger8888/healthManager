//
//  ChatViewController.m
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import "ChatViewController.h"
#import "QFXmppManager.h"
#import "NSData+Base64.h"

@interface ChatViewController ()

@end

@implementation ChatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    _allChatList = [[NSMutableArray alloc] init];

    // 接收从别人
    [[QFXmppManager shareInstance] registerForMessage:
        ^(MessageModel *oneMessage) {
            [_allChatList addObject:oneMessage];
            NSLog(@"_arr is %@", _allChatList);
            [_tableView reloadData];
    }];
    
    [self createSendButton];
}

- (void) createSendButton {
    UIBarButtonItem *sendItm = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(sendMessage)];
    self.navigationItem.rightBarButtonItem = sendItm;
}
@synthesize toUser = _toUser;
- (void) sendMessagePic {
    // 发图片 or Text
    UIImage *img = [UIImage imageNamed:@"online.png"];
    NSData *data = UIImagePNGRepresentation(img);
    NSString *dataBase64 = [data base64EncodedString];
    
    [[QFXmppManager shareInstance] sendMessage:dataBase64 withType:kMsgImage toUser:_toUser withCompletion:^(BOOL ret) {
        NSLog(@"发送图片完成了%d", ret);
    }];
}
- (void) sendMessage {
    [self sendMessageText];
    [self sendMessagePic];
}
- (void) sendMessageText {
    
    static int count;
    NSString *msg = [NSString stringWithFormat:@"发送%d", count++];
    [[QFXmppManager shareInstance] sendMessage:msg withType:kMsgText toUser:_toUser withCompletion:^(BOOL ret) {
        NSLog(@"发送完成了%d", ret);
    }];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_allChatList count];
}
-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellid = @"My Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellid];
    }
    MessageModel *um = [_allChatList objectAtIndex:indexPath.row];
    if (um.image) {
        cell.imageView.image = um.image;
    } else {
        cell.textLabel.text = um.msg;
    }

    return cell;
}

@end










