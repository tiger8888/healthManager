//
//  LoginViewController.m
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import "LoginViewController.h"
#import "QFXmppManager.h"
#import "FriendListViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   // self.usernameField.text = @"changcunyuan@1000phone.net";
    // self.passwordField.text = @"123456";
    self.usernameField.text = @"iphonerao@127.0.0.1";
    self.passwordField.text = @"iphonerao";
  
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)regClick:(id)sender {
    // 初始化...注册
    NSLog(@"这是注册");
    [[QFXmppManager shareInstance]
         registerUser:self.usernameField.text
         withPassword:self.passwordField.text
         withCompletion:
               ^(BOOL ret, NSError *err) {
                   if (ret == YES) {
                       NSLog(@"注册成功");
                   } else {
                       NSLog(@"失败 %@", err);
                   }
            }
     ];
}

- (IBAction)loginClick:(id)sender {
    [[QFXmppManager shareInstance]
     loginUser:self.usernameField.text
     withPassword:self.passwordField.text
     withCompletion:
     ^(BOOL ret, NSError *err) {
         if (ret == YES) {
             NSLog(@"登陆成功");
             FriendListViewController *flc = [[FriendListViewController alloc] init];
             UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:flc];
             [self presentViewController:nav animated:YES completion:^{
                 
             }];
             
             
         } else {
             NSLog(@"登陆失败 %@", err);
         }
     }
     ];

}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.usernameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
}

@end
