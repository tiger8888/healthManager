//
//  MessageModel.h
//  ChatDemo
//
//  Created by yang on 17/11/13.
//  Copyright (c) 2013 raojunbomac. All rights reserved.
//

#import <Foundation/Foundation.h>
#define PropertyString(s) @property (nonatomic, copy) NSString *s
@interface MessageModel : NSObject {
    NSString *_msg;
    NSString *_from;
    NSString *_to;
}
- (UIImage *) image;
PropertyString(msg);
PropertyString(from);
PropertyString(to);

@end
