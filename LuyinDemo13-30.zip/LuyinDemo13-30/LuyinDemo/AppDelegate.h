//
//  AppDelegate.h
//  LuyinDemo
//
//  Created by wangjianwei on 13-10-25.
//  Copyright (c) 2013年 wangjianwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
