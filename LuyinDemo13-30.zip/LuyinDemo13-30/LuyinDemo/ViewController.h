//
//  ViewController.h
//  LuyinDemo
//
//  Created by wangjianwei on 13-10-25.
//  Copyright (c) 2013年 wangjianwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreAudio/CoreAudioTypes.h>
#import "VoiceConverter.h"
@interface ViewController : UIViewController <AVAudioRecorderDelegate> {

    UIButton *luyinBtn;
    UIButton *playBtn;

    NSURL *recordedTmpFile;
    AVAudioRecorder *recorder;
    NSError *error;
    
    //我默认不要stop，只有暂停和开始
    BOOL isPause;

    
    BOOL isStop;

}

-(void)startProximityMonitering;//开启近距离监听
-(void)stopProximityMonitering;//关闭近距离监听

@end
