//
//  ViewController.m
//  LuyinDemo
//
//  Created by wangjianwei on 13-10-25.
//  Copyright (c) 2013年 wangjianwei. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    /*
     进入界面了，先测试，录音和暂停，然后播放，之后有文件了，就可以测试，压缩了。
     */
    
	// Do any additional setup after loading the view, typically from a nib.
    
    luyinBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [luyinBtn setTitle:@"开始录音" forState:UIControlStateNormal];
    [luyinBtn addTarget:self action:@selector(luyinEvent) forControlEvents:UIControlEventTouchUpInside];
    luyinBtn.frame=CGRectMake(50, 200, 80, 40);
    [self.view addSubview:luyinBtn];
    
    playBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [playBtn setTitle:@"播放" forState:UIControlStateNormal];
    [playBtn addTarget:self action:@selector(playEvent) forControlEvents:UIControlEventTouchUpInside];
    playBtn.frame=CGRectMake(200, 200, 80, 40);
    [self.view addSubview:playBtn];
    
    isStop=YES;
    isPause = YES;//默认是暂停，也就是没有开启。
    /*
     
     加上暂停有一个不好的地方，就是如果你要播放的话，必须去stop，因为你不去调用stop生成不了文件。
     */
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:&error];
    [audioSession setActive:YES error:&error];
    
    
    UIButton *zhhuanBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [zhhuanBtn setTitle:@"转换成小的音频，也就是压缩的意思" forState:UIControlStateNormal];
    [zhhuanBtn addTarget:self action:@selector(zhhuanBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    zhhuanBtn.frame=CGRectMake(0, 300, 320, 40);
    [self.view addSubview:zhhuanBtn];
}
-(void)zhhuanBtnEvent{
    /*
     
     仔细看这里，第一个视频地址是你的wav，第二个path是要输出的amr路径。你弄好路径，直接调用这个方法就可以了。
      */
     NSString *strPath1 = [NSTemporaryDirectory() stringByAppendingString:@"/test.wav"];
     NSString *strPath2 = [NSTemporaryDirectory() stringByAppendingString:@"/test2.amr"];
     [VoiceConverter wavToAmr:strPath1 amrSavePath:strPath2];
    
}

-(void)luyinEvent {
    
    if (isPause == YES) {
        //要么没有开启录音，要么是暂停的
        if (recorder==nil) {
            NSMutableDictionary* recordSetting = [[NSMutableDictionary alloc] init];
            
            [recordSetting setValue :[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey:AVFormatIDKey];
            
            [recordSetting setValue:[NSNumber numberWithFloat:0.4] forKey:AVSampleRateKey];
            [recordSetting setValue:[NSNumber numberWithInt: 0.7] forKey:AVNumberOfChannelsKey];
            
            //录音文件保存的地址。
            
            /*
             
             recordedTmpFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%.0f.%@", [NSDate timeIntervalSinceReferenceDate] * 1000.0, @"wav"]]];这个是之前的路径
             
                recordedTmpFile 我现在把地址写死。好转换。
             
             */

            recordedTmpFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:@"test.wav"]];
            NSLog(@"Using File called: %@",recordedTmpFile);
            
            recorder = [[ AVAudioRecorder alloc] initWithURL:recordedTmpFile settings:recordSetting error:&error];
            
            [recorder setDelegate:self];
            
            [recorder prepareToRecord];
            [recorder record];
        }else{
            
            [recorder record];
        }
        
        isPause = NO;
        
        [luyinBtn setTitle:@"暂停录音" forState:UIControlStateNormal];

        
    }else{
        [recorder pause];
        isPause = YES;
        [luyinBtn setTitle:@"开始录音" forState:UIControlStateNormal];

    }
    /*
    if (isStop) {
        isStop=NO;
        [luyinBtn setTitle:@"停止" forState:UIControlStateNormal];
        NSMutableDictionary* recordSetting = [[NSMutableDictionary alloc] init];
        
        [recordSetting setValue :[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey:AVFormatIDKey];
        
        [recordSetting setValue:[NSNumber numberWithFloat:0.4] forKey:AVSampleRateKey];
        [recordSetting setValue:[NSNumber numberWithInt: 0.7] forKey:AVNumberOfChannelsKey];
        
        recordedTmpFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%.0f.%@", [NSDate timeIntervalSinceReferenceDate] * 1000.0, @"wav"]]];
        NSLog(@"Using File called: %@",recordedTmpFile);
        
        recorder = [[ AVAudioRecorder alloc] initWithURL:recordedTmpFile settings:recordSetting error:&error];
        
        [recorder setDelegate:self];
        
        [recorder prepareToRecord];
        [recorder record];  
        
    } else {
        isStop=YES;
        [luyinBtn setTitle:@"录音" forState:UIControlStateNormal];
        [recorder stop];
    }
    
    */
}

-(void)playEvent {
    
    [recorder stop];
    isStop=YES;

    
    /*如果想要播放的话，必须调用stop方法，要不然，文件没有结束符号，生成的音频用不了*/
    AVAudioPlayer * avPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:recordedTmpFile error:&error];
    [avPlayer prepareToPlay];
    [avPlayer play];
}


-(void)startProximityMonitering {
    [[UIDevice currentDevice]setProximityMonitoringEnabled:YES];
     NSLog(@"开启距离监听");
}

-(void)stopProximityMonitering {
    
    
    [[AVAudioSession sharedInstance]setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [[UIDevice currentDevice]setProximityMonitoringEnabled:NO];
     NSLog(@"关闭距离监听");
}


- (void)viewDidUnload {
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    //Clean up the temp file.
    NSFileManager * fm = [NSFileManager defaultManager];
    [fm removeItemAtPath:[recordedTmpFile path] error:&error];
    //Call the dealloc on the remaining objects.
    [recorder dealloc];
    recorder = nil;
    recordedTmpFile = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
